﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankHandlers
{
    public class AccountListener
    {
        public static void BlockAccount()
        {
            Console.WriteLine("Your card has been locked.");
        }

        public static void SendEmail()
        {
            Console.WriteLine("Email has been sent to Account Holder.");
        }
    }
}
