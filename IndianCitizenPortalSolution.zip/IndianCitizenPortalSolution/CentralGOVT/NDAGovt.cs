﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralGOVT
{
    public class NDAGovt
    {
        public static void PayIncomeTax()
        {
            Console.WriteLine("Income Tax is deducted  10%");
        }
        public static void PayServiceTax()
        {
            Console.WriteLine(" Service Tax is deducted 14%");
        }
        public static void PayProfessionalTax()
        {
            Console.WriteLine("Professional Tax is deducted  8%");
        }
    }
}
