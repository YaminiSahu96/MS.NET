﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralGOVT
{
     public class UPAGovt
    {

        public static void PayIncomeTax()
        {
            Console.WriteLine("Income Tax is deducted 5%");
        }
        public static void PayServiceTax()
        {
            Console.WriteLine(" Service Tax is deducted 8%");
        }
        public static void PayProfessionalTax()
        {
            Console.WriteLine("Professional Tax is deducted  35%");
        }
    }
}
