﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;
using CentralGOVT;
using BankHandlers;
namespace Portal
{
    class Program
    {
        static void Main(string[] args)
        {

            Account acct1 = new Account(15000);
            acct1.UnderBalance += new Operation(AccountListener.BlockAccount);
            acct1.UnderBalance += new Operation(AccountListener.SendEmail);
            acct1.OverBalance += new Operation(UPAGovt.PayIncomeTax);

            //acct1.Deposit(300000);
            acct1.Withdraw(11000);
            //.....
            //.....
            Console.ReadLine();

        }
    }
}
