﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphicsEditor1
{
    enum shapes{
            line,
            rect,
            noshape
    }

    public partial class Form1 : Form
    {
        shapes shape = shapes.noshape;
        Color color = new Color();

        public Form1()
        {
            InitializeComponent();
        }

        

        private void OnShapeLine(object sender, EventArgs e)
        {
            Graphics g = CreateGraphics();
            Pen p = new Pen(color,5);
            g.DrawLine(p, startPoint, endPoint);
             shape = shapes.line;

        }
        Point startPoint = new Point(23, 23);
        Point endPoint = new Point(300, 300);
        Point width = new Point(20, 20);
        Point height = new Point(30, 30);
        Color shapeColor;

        private void rectangleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics d =this.CreateGraphics();
            Pen p = new Pen(color, 6);
            d.DrawRectangle(p, 100,230, 20, 45);
             shape = shapes.rect;
        }


        private void onPenColor(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            if(c.ShowDialog() == DialogResult.OK)
            {
                color = c.Color;
            }
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Are you Sure ?", "DAY3_Assign", MessageBoxButtons.OKCancel);
            this.Close();
        }

        private void shapeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mnuItemRectangle_MouseUp(object sender, MouseEventArgs e)
        {
            this.endPoint = new Point(e.X, e.Y);
            Graphics d = this.CreateGraphics();

           
            if (shape == shapes.line)
            {
                Pen thePen = new Pen(Color.Black, 5);
                d.DrawLine(thePen, startPoint, endPoint);
                
            }
            else
            {
                Pen thePen = new Pen(Color.White, 5);
                int width = endPoint.X - startPoint.X;
                int height = endPoint.Y - startPoint.Y;
                d.DrawRectangle(thePen, startPoint.X, endPoint.Y, width, height);
            }

            
        }

        private void mnuItemLine_MouseDown(object sender, MouseEventArgs e)
        {
            this.startPoint = new Point(e.X, e.Y);
        }
    }
}
