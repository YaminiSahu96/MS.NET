﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    public delegate void Operation();
    public class Account
    {
        public event Operation UnderBalance;
        public event Operation OverBalance;
        public Account(double amount)
        {
            this.balance = amount;
        }
        private double balance;
        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
        public void Deposit(double amount)
        {
            Balance += amount;
            Monitor();
        }
        public void Withdraw(double amount)
        {
            Balance -= amount;
            Monitor();
        }
        void Monitor()
        {
            if(balance< 5000)
            {   //raise an event
                UnderBalance();
            }
            else if(balance >=25000)
            {   OverBalance();
            }
        }
    }
}
