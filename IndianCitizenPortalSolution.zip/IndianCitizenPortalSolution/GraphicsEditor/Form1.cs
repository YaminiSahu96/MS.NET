﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphicsEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void OnFileExit(object sender, EventArgs e)
        {
            MessageBox.Show("Are you Sure ?", "Transflower", MessageBoxButtons.OKCancel);
            this.Close();
        }

        private void OnShapeLine(object sender, EventArgs e)
        {/*
            Graphics g = this.CreateGraphics();
            //Pen thePen = new Pen(Color.Red,5);
            Pen thePen = new Pen(shapeColor, 5);
            //Point startPoint = new Point(23, 23);
            //Point endPoint = new Point(300, 300);
           g.DrawLine(thePen, startPoint, endPoint);
            int width = endPoint.X - startPoint.X;
            int height = endPoint.Y - startPoint.Y;

            //g.DrawRectangle(thePen, startPoint.X, startPoint.Y, width, height);
        
            
            */
        }

        Point startPoint = new Point(23, 23);
        Point endPoint = new Point(300, 300);
        Color shapeColor;

        private void OnGdiPenColor(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
           if( dlg.ShowDialog()==DialogResult.OK)
            {
                shapeColor = dlg.Color;
            }

        }

        private void OnMouseDown(object sender, MouseEventArgs e)
        {
            this.startPoint = new Point(e.X, e.Y);
        }

        private void OnMouseUp(object sender, MouseEventArgs e)
        {
            this.endPoint = new Point(e.X, e.Y);


            Graphics g = this.CreateGraphics();
            //Pen thePen = new Pen(Color.Red,5);
            Pen thePen = new Pen(shapeColor, 5);
            //Point startPoint = new Point(23, 23);
            //Point endPoint = new Point(300, 300);
            g.DrawLine(thePen, startPoint, endPoint);
            int width = endPoint.X - startPoint.X;
            int height = endPoint.Y - startPoint.Y;

        }

        private void Form1_DragLeave(object sender, EventArgs e)
        {

        }





        //Callback function
        //Action Listener
        //Event handler
        //Receiver
        //Controller

    }
}
